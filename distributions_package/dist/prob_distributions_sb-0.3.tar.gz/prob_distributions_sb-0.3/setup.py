from setuptools import setup

setup(name='prob_distributions_sb',
      version='0.3',
      description='Gaussian, Binomial distributions',
      packages=['prob_distributions_sb'],
      author = 'Spurthi Bollina',
      author_email = 'bollinaspurthi@gmail.com',
      zip_safe=False)
